import 'package:ams_projeto_2semestre/revisao/produto_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(ClassAMSApp());
}

// Nome padrão nomed_do_projetoApp ou MyApp
class ClassAMSApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Esse titulo é o que aparece na playstore ou na pagina inicial da tela
      title: 'Projeto AMS',
      home: ProdutoPage(),
    );
  }
}