import 'package:flutter/material.dart';

class ProdutoPage extends StatefulWidget{
  // @override createState
  @override
  State<StatefulWidget> createState() {
    return ProdutoState();
  }
}

class ProdutoState extends State<ProdutoPage>{
  // @override build
  @override Widget build(BuildContext context) {
    return Scaffold(

      // appBar(nome da propriedade): AppBar(classe)
      appBar: AppBar(
        title: Text('Revisao'),
      ),

      // body aceita apenas um componente, porém ele aceita componentes agrupadores(Collum, Padding com child: Column) que aceitam varios
      body: Padding(
        padding: EdgeInsetsGeometry.all(10),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Digite o nome do produto',
                hintText: 'Ex: Coca Cola 2 litros',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){},
              child: Text('Salvar'),
            ),

          ]
        )
      )

    );
  }
}