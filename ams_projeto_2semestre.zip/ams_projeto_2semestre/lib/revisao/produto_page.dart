import 'package:flutter/material.dart';

class ProdutoPage extends StatefulWidget{
  // @override createState
  @override
  State<StatefulWidget> createState() {
    return ProdutoState();
  }
}

class ProdutoState extends State<ProdutoPage>{
  TextEditingController _nomeControlador = TextEditingController();
  TextEditingController _precoControlador = TextEditingController();
  TextEditingController _quantidadeControlador = TextEditingController();
  String mensagem = ''; // String? opcional

  void Salvar() {
    // tipo var descobre automaticamente o tipo da variavel pelo numero que está sendo jogado nela. Pode haver erro dependendo do caso
    String nome = _nomeControlador.text.trim(); // ,trim impede que espaço em branco(" ") seja considerado como not empty
    String preco = _precoControlador.text.trim(); // Para evitar erros de validação(tipo errado) primeira é dado em String o Text
    String quantidade = _quantidadeControlador.text.trim();

    if(nome.isEmpty) {
      setState(() {
        mensagem = 'O campo nome é obrigatório!';
      });
      return;
    }

    if(nome.length < 3 || nome.length > 50) {
      setState(() {
        mensagem = 'O nome deve ter entre 3 e 50 caracteres';
      });
      return;
    }

    if(preco.isEmpty) {
      setState(() {
        mensagem = 'O campo preço é obrigatório!';
      });
      return;
    }

    // RegExp é uma classe do dart para uma expressão regular(formula)
    // r'' significa que vai ter um texto dentro que deve igualar o preco
    // r'^ significa inicio - $' significa fim
    // \d significa que vai escrever um digito. + um ou mais digitos
    // ()? o que esta dentro do parentese é opcional(indicado pelo ?). [] significa que o que está dentro pode ser um ou outro dos caracteres dentro
    // \d+ significa infitas casas para frente. \d{} siginifica que está sendo limitado o conteudo pela quantidade de caracteres que está dentro do {}. { n, n} pode ser um ou outro
    if(!RegExp(r'^\d+([,.]\d{1,2})?$').hasMatch(preco)) {
      setState(() {
        mensagem = 'O preco deve ter no maximo duas casas decimais';
      });
      return;
    }

    // Tenta validar preco como double se não manda como vazio. Substitui todas as ',' por '.' para evitar erros de sistema
    double? preco_convertido = double.tryParse(preco.replaceAll(',', '.'));

    if(preco_convertido == null){
      setState(() {
        mensagem = 'Valor informado no campo preço é invalido!';
      });
      return;
    }

    // Limita a quantidade minima e maxima permitida no sistema
    if(preco_convertido < 0.10 || preco_convertido > 1000) {
      setState(() {
        mensagem = 'Valor informado no campo preco deve estar entre R\$ 0,10 e R\$ 1000,00!'; // Para colocar o $ sem entrar em conflito com a configuração do Dart tem que ter a \ 
      });
      return;
    }


    if(quantidade.isEmpty) {
      setState(() {
        mensagem = 'O campo quantidade é obrigatório!';
      });
      return;
    }

    // Tenta validar como int, se não o campo fica como vazio e envia uma mensagem informando
    int? quantidade_convertida = int.tryParse(quantidade);

    if(quantidade_convertida == null){
      setState(() {
        mensagem = 'Valor informado no campo quantidade é invalido!';
      });
      return;
    }

    // Limita a quantidade minima e maxima dos produtos
    if(quantidade_convertida <= 0 || quantidade_convertida > 100) {
      setState(() {
        mensagem = 'Valor informado no campo quantidade deve estar entre 1 e 100!';
      });
    }

    setState(() {
      mensagem = 'Produto salvo com sucesso!';
    });
  }

  // @override build
  @override Widget build(BuildContext context) {
    return Scaffold(

      // appBar(nome da propriedade): AppBar(classe)
      appBar: AppBar(
        title: Text('Revisao'),
      ),

      // body aceita apenas um componente, porém ele aceita componentes agrupadores(Collum, Padding com child: Column) que aceitam varios
      body: Padding(
        padding: EdgeInsetsGeometry.all(10),
        child: Column(
          children: [
            TextField(
              controller: _nomeControlador,
              decoration: InputDecoration(
                labelText: 'Digite o nome do produto',
                hintText: 'Ex: Coca Cola 2 litros',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _precoControlador,
              decoration: InputDecoration(
                labelText: 'Digite o preco produto',
                hintText: 'Ex: 12.50',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _quantidadeControlador,
              decoration: InputDecoration(
                labelText: 'Digite a quantidade do produto',
                hintText: 'Ex: 10',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            Text(
              mensagem
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){Salvar();},
              child: Text('Salvar'),
            ),

          ]
        )
      )

    );
  }
}