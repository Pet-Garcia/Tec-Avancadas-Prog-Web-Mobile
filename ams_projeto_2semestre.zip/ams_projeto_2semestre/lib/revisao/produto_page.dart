import 'package:flutter/material.dart';

class ProdutoPage extends StatefulWidget{
  // @override createState
  @override
  State<StatefulWidget> createState() {
    return ProdutoState();
  }
}

class ProdutoState extends State<ProdutoPage>{
  TextEditingController _nomeControlador = TextEditingController();
  TextEditingController _precoControlador = TextEditingController();
  TextEditingController _quantidadeControlador = TextEditingController();
  String mensagem = ''; // String? opcional

  void Salvar() {
    // tipo var descobre automaticamente o tipo da variavel pelo numero que está sendo jogado nela. Pode haver erro dependendo do caso
    String nome = _nomeControlador.text.trim(); // ,trim impede que espaço em branco(" ") seja considerado como not empty
    String preco = _precoControlador.text.trim(); // Para evitar erros de validação(tipo errado) primeira é dado em String o Text
    String quantidade = _quantidadeControlador.text.trim();

    if(nome.isEmpty) {
      setState(() {
        mensagem = 'O campo nome é obrigatório!';
      });
      return;
    }

    if(preco.isEmpty) {
      setState(() {
        mensagem = 'O campo preço é obrigatório!';
      });
      return;
    }

    if(quantidade.isEmpty) {
      setState(() {
        mensagem = 'O campo quantidade é obrigatório!';
      });
      return;
    }

    setState(() {
      mensagem = 'Produto salvo com sucesso!';
    });
  }

  // @override build
  @override Widget build(BuildContext context) {
    return Scaffold(

      // appBar(nome da propriedade): AppBar(classe)
      appBar: AppBar(
        title: Text('Revisao'),
      ),

      // body aceita apenas um componente, porém ele aceita componentes agrupadores(Collum, Padding com child: Column) que aceitam varios
      body: Padding(
        padding: EdgeInsetsGeometry.all(10),
        child: Column(
          children: [
            TextField(
              controller: _nomeControlador,
              decoration: InputDecoration(
                labelText: 'Digite o nome do produto',
                hintText: 'Ex: Coca Cola 2 litros',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _precoControlador,
              decoration: InputDecoration(
                labelText: 'Digite o preco produto',
                hintText: 'Ex: 12.50',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _quantidadeControlador,
              decoration: InputDecoration(
                labelText: 'Digite a quantidade do produto',
                hintText: 'Ex: 10',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            Text(
              mensagem
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){Salvar();},
              child: Text('Salvar'),
            ),

          ]
        )
      )

    );
  }
}