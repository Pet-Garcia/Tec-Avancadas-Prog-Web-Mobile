import 'package:flutter/material.dart';

class Ex3_AlunosPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Ex3_AlunosState();
  }
}

class Ex3_AlunosState extends State<Ex3_AlunosPage> {
  // Controllers para os campos de texto
  TextEditingController _nomeControlador = TextEditingController();
  TextEditingController _idadeControlador = TextEditingController();
  TextEditingController _emailControlador = TextEditingController();
  String? mensagem;

  Salvar() {
    // Variaveis
    String nome = _nomeControlador.text.trim();
    String idade = _idadeControlador.text.trim();
    String email = _emailControlador.text.trim();

    // Validações
    // Validação do campo nome
    if(nome.isEmpty) {
      setState(() {
        mensagem = 'O campo nome é obrigatório!';
      });
      return;
    }
    if(nome.length < 3 || nome.length > 50) {
      setState(() {
        mensagem = 'O nome deve ter entre 3 e 50 caracteres';
      });
      return;
    }

    // Validação do campo idade
    if(idade.isEmpty) {
      setState(() {
        mensagem = 'O campo idade é obrigatório!';
      });
      return;
    }
    int? idade_convertida = int.tryParse(idade);
    if(idade_convertida == null) {
      setState(() {
        mensagem = 'A idade deve ser um número inteiro';
      });
      return;
    }
    if(idade_convertida < 10 || idade_convertida > 100) {
      setState(() {
        mensagem = 'A idade deve estar entre 10 e 100 anos';
      });
      return;
    }

    // Validação do campo email
    if(email.isEmpty) {
      setState(() {
        mensagem = 'O campo email é obrigatório!';
      });
      return;
    }
    // (r'Usuario[@ obrigatorio]dominio[\. deve ter ponto]A extenção do dominio deve ter pelo menos 2 caracteres')
    if(!RegExp(r'^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}$').hasMatch(email)) {
      setState(() {
        mensagem = 'O email deve ser válido';
      });
      return;
    }

    setState(() {
      mensagem = 'Aluno salvo com sucesso';
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Exercício 3 - Cadastro de Aluno'),
      ),
      body: Padding(
        padding: EdgeInsets.all(25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _nomeControlador,
              decoration: InputDecoration(
                labelText: 'Digite o nome do aluno',
                hintText: 'Ayron da Silva',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _idadeControlador,
              decoration: InputDecoration(
                labelText: 'Digite a idade do aluno',
                hintText: '25',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _emailControlador,
              decoration: InputDecoration(
                labelText: 'Digite o email do aluno',
                hintText: 'ayron.silva@gmail.com',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            Text(
              mensagem ?? '',
            ),

            ElevatedButton(
              onPressed: (){Salvar();},
              child: Text('Cadastrar Aluno'),
            )
          ]
        ),
      ),
    );
  }
}