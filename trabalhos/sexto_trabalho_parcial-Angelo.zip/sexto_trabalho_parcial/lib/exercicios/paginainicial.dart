import 'package:flutter/material.dart';
import 'package:sexto_trabalho_parcial/exercicios/ex1_veiculos.dart';
import 'package:sexto_trabalho_parcial/exercicios/ex2_filmes.dart';
import 'package:sexto_trabalho_parcial/exercicios/ex3_alunos.dart';
import 'package:sexto_trabalho_parcial/exercicios/ex4_livros.dart';
import 'package:sexto_trabalho_parcial/exercicios/ex5_eventos.dart';
import 'package:sexto_trabalho_parcial/exercicios/ex6_usuarios.dart';

class PaginaInicialPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return PaginaInicialState();
  }
}

class PaginaInicialState extends State<PaginaInicialPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Página Inicial'),
      ),
      body: Padding(
        padding: EdgeInsets.all(25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex1_VeiculoPage())
                );
              },
              child: Text('Exercício 1 - Cadastro de Veículo'),
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex2_FilmePage())
                );
              },
              child: Text('Exercício 2 - Cadastro de Filme'),
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex3_AlunosPage())
                );
              },
              child: Text('Exercício 3 - Cadastro de Aluno'),
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex4_LivrosPage())
                );
              },
              child: Text('Exercício 4 - Cadastro de Livros'),
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex5_EventosPage())
                );
              },
              child: Text('Exercício 5 - Cadastro de Eventos'),
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex6_UsuariosPage())
                );
              },
              child: Text('Exercício 6 - Cadastro de Usuários'),
            )
          ]
        ),
      ),
    );
  }
}