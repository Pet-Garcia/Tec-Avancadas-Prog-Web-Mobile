import 'package:flutter/material.dart';

class Ex2_FilmePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Ex2_FilmeState();
  }
}

class Ex2_FilmeState extends State<Ex2_FilmePage> {

  // Controllers para os campos de texto
  TextEditingController _nomeControlador = TextEditingController();
  TextEditingController _dataControlador = TextEditingController();
  TextEditingController _duracaoControlador = TextEditingController();
  String? mensagem;

  Salvar(){
    // Variaveis
    String nome = _nomeControlador.text.trim();
    String data = _dataControlador.text.trim();
    String duracao = _duracaoControlador.text.trim();

    // Validações
    // Validação do campo nome
    if(nome.isEmpty) {
      setState(() {
        mensagem = 'O campo nome é obrigatório!';
      });
      return;
    }
    if(nome.length < 2 || nome.length > 100) {
      setState(() {
        mensagem = 'O nome deve ter entre 2 e 100 caracteres';
      });
      return;
    }

    // Validação do campo data
    if(data.isEmpty) {
      setState(() {
        mensagem = 'O campo data é obrigatório!';
      });
      return;
    }
    if(!RegExp(r'^(0[1-9]|[12][0-9]|3[01])[/](0[1-9]|1[0-2])[/]\d{4}$').hasMatch(data)) {
      setState(() {
        mensagem = 'A data deve estar no formato dd/mm/aaaa e ser uma data válida';
      });
      return;
    }

    // Validação do campo duracao
    if(duracao.isEmpty) {
      setState(() {
        mensagem = 'O campo duração é obrigatório!';
      });
      return;
    }
    int? duracao_convertido = int.tryParse(duracao);
    if(duracao_convertido == null) {
      setState(() {
        mensagem = 'A duração deve ser um número inteiro';
      });
      return;
    }
    if(duracao_convertido < 0 || duracao_convertido > 500) {
      setState(() {
        mensagem = 'A duração deve estar entre 0 e 500 minutos';
      });
      return;
    }

    // Validação de sucesso
    setState(() {
      mensagem = 'Filme salvo com sucesso';
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Exercício 2 - Cadastro de Filme'),
      ),
      body: Padding(
        padding: EdgeInsets.all(25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _nomeControlador,
              decoration: InputDecoration(
                labelText: 'Digite o nome do filme',
                hintText: 'Jogador Número 1',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _dataControlador,
              decoration: InputDecoration(
                labelText: 'Digite a data do filme',
                hintText: '29/03/2018',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _duracaoControlador,
              decoration: InputDecoration(
                labelText: 'Digite a duração do filme',
                hintText: '140',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            Text(
              mensagem ?? '',
            ),

            ElevatedButton(
              onPressed: (){Salvar();},
              child: Text('Cadastrar Filme'),
            )
          ]
        ),
      ),
    );
  }
}