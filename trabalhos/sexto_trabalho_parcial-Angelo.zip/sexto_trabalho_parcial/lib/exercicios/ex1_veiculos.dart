import 'package:flutter/material.dart';

class Ex1_VeiculoPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Ex1_VeiculoState();
  }
}

class Ex1_VeiculoState extends State<Ex1_VeiculoPage> {

  // Controllers para os campos de texto
  TextEditingController _marcaControlador = TextEditingController();
  TextEditingController _modeloControlador = TextEditingController();
  TextEditingController _anoControlador = TextEditingController();
  TextEditingController _precoControlador = TextEditingController();
  String? mensagem;

  void Salvar(){

    // Variaveis
    String marca = _marcaControlador.text.trim();
    String modelo = _modeloControlador.text.trim();
    String ano = _anoControlador.text.trim();
    String preco = _precoControlador.text.trim();

    // Validações
    // Validação do campo marca
    if(marca.isEmpty) {
      setState(() {
        mensagem = 'O campo marca é obrigatório!';
      });
      return;
    }
    if(marca.length < 2 || marca.length > 50) {
      setState(() {
        mensagem = 'A marca deve ter entre 2 e 50 caracteres';
      });
      return;
    }

    // Validação do campo modelo
    if(modelo.isEmpty) {
      setState(() {
        mensagem = 'O campo modelo é obrigatório!';
      });
      return;
    }
    if(modelo.length < 2 || modelo.length > 50) {
      setState(() {
        mensagem = 'O modelo deve ter entre 2 e 50 caracteres';
      });
      return;
    }

    // Validação do campo ano
    if(ano.isEmpty) {
      setState(() {
        mensagem = 'O campo ano é obrigatório!';
      });
      return;
    }
    if(!RegExp(r'^\d+([,.]\d{0})?$').hasMatch(ano)) {
      setState(() {
        mensagem = 'O ano deve ser um número inteiro';
      });
      return;
    }
    int? ano_convertido = int.tryParse(ano);
    if(ano_convertido == null) {
      setState(() {
        mensagem = 'Valor informado no campo ano é invalido!';
      });
      return;
    }
    if(ano_convertido < 1900 || ano_convertido > 2026) {
      setState(() {
        mensagem = 'O ano deve estar entre 1900 e 2026';
      });
      return;
    }

    // Validação do campo preço
    if(preco.isEmpty) {
      setState(() {
        mensagem = 'O campo preço é obrigatório!';
      });
      return;
    }
    if(!RegExp(r'^\d+([,.]\d{1,2})?$').hasMatch(preco)) {
      setState(() {
        mensagem = 'O preço deve ter no máximo duas casas decimais';
      });
      return;
    }
    double? preco_convertido = double.tryParse(preco.replaceAll(',','.'));
    if(preco_convertido == null) {
      setState(() {
        mensagem = 'Valor informado no campo preço é inválido!';
      });
      return;
    }
    if(preco_convertido < 1000 || preco_convertido > 1000000) {
      setState(() {
        mensagem = 'O preço deve estar entre R\$ 1.000,00 e R\$ 1.000.000,00';
      });
      return;
    }

    // Validação concluída com sucesso
    setState(() {
      mensagem = 'Veículo salvo com sucesso';
    });



  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Exercício 1 - Cadastro de Veículo'),
      ),
      body: Padding(
        padding: EdgeInsets.all(25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _marcaControlador,
              decoration: InputDecoration(
                labelText: 'Digite a marca do carro',
                hintText: 'Corsa',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _modeloControlador,
              decoration: InputDecoration(
                labelText: 'Digite o modelo do carro',
                hintText: 'oi',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _anoControlador,
              decoration: InputDecoration(
                labelText: 'Digite o ano de fabricação do carro',
                hintText: '1999',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _precoControlador,
              decoration: InputDecoration(
                labelText: 'Digite o preço do carro',
                hintText: '14.599,00',
                border: OutlineInputBorder(),
              )
            ),

            SizedBox(
              height: 20,
            ),

            Text(
              mensagem ?? '',
            ),

            ElevatedButton(
              onPressed: (){Salvar();},
              child: Text('Cadastrar Veículo'),
            )
          ]
        ),
      ),
    );
  }
}