import 'package:flutter/material.dart';

class Ex4_LivrosPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Ex4_LivrosState();
  }
}

class Ex4_LivrosState extends State<Ex4_LivrosPage> {

  // Controllers para os campos de texto
  TextEditingController _tituloControlador = TextEditingController();
  TextEditingController _autorControlador = TextEditingController();
  TextEditingController _numpaginasControlador = TextEditingController();
  TextEditingController _codigoControlador = TextEditingController();
  String? mensagem;

  Salvar() {

    // Variaveis
    String titulo = _tituloControlador.text.trim();
    String autor = _autorControlador.text.trim();
    String numPaginas = _numpaginasControlador.text.trim();
    String codigo = _codigoControlador.text.trim();

    // Validações
    // Validação do campo titulo
    if(titulo.isEmpty) {
      setState(() {
        mensagem = 'O campo título é obrigatório!';
      });
      return;
    }
    if(titulo.length < 2 || titulo.length > 100) {
      setState(() {
        mensagem = 'O título deve ter entre 2 e 100 caracteres';
      });
      return;
    }

    // Validação do campo autor
    if(autor.isEmpty) {
      setState(() {
        mensagem = 'O campo autor é obrigatório!';
      });
      return;
    }
    if(autor.length < 3 || autor.length > 100) {
      setState(() {
        mensagem = 'O autor deve ter entre 3 e 100 caracteres';
      });
      return;
    }

    // Validação do campo numPaginas
    if(numPaginas.isEmpty) {
      setState(() {
        mensagem = 'O campo número de páginas é obrigatório!';
      });
      return;
    }
    int? numPaginas_convertido = int.tryParse(numPaginas);
    if(numPaginas_convertido == null) {
      setState(() {
        mensagem = 'O número de páginas deve ser um número inteiro';
      });
      return;
    }
    if(numPaginas_convertido < 1 || numPaginas_convertido > 10000) {
      setState(() {
        mensagem = 'O número de páginas deve estar entre 1 e 10 mil (10000)';
      });
      return;
    }

    // Validação do campo codigo
    if(codigo.isEmpty) {
      setState(() {
        mensagem = 'O campo código é obrigatório!';
      });
      return;
    }
    if(!RegExp(r'^[A-Za-z]{3}-\d{4}$').hasMatch(codigo)) {
      setState(() {
        mensagem = 'O código deve estar no formato ABC-0123';
      });
      return;
    }

    setState(() {
      mensagem = 'Livro salvo com sucesso';
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Exercício 4 - Cadastro de Livros'),
      ),
      body: Padding(
        padding: EdgeInsets.all(25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 20,
            ),
            
            TextField(
              controller: _tituloControlador,
              decoration: InputDecoration(
                labelText: 'Digite o título do livro',
                hintText: 'O Senhor dos Anéis',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _autorControlador,
              decoration: InputDecoration(
                labelText: 'Digite o autor do livro',
                hintText: 'J.R.R. Tolkien',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _numpaginasControlador,
              decoration: InputDecoration(
                labelText: 'Digite o número de páginas do livro',
                hintText: '1007',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _codigoControlador,
              decoration: InputDecoration(
                labelText: 'Digite o código do livro',
                hintText: 'ABC-0123',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            Text(
              mensagem ?? '',
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){Salvar();},
              child: Text('Cadastrar Livro'),
            ),
          ],
        ),
      ),
    );
  }
}