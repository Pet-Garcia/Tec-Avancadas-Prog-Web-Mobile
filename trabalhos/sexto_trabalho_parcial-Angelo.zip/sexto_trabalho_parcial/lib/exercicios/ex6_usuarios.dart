import 'package:flutter/material.dart';

class Ex6_UsuariosPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Ex6_UsuariosState();
  }
}

class Ex6_UsuariosState extends State<Ex6_UsuariosPage> {

  // Controllers para os campos de texto
  TextEditingController _nomeControlador = TextEditingController();
  TextEditingController _emailControlador = TextEditingController();
  TextEditingController _senhaControlador = TextEditingController();
  TextEditingController _senhaConfirmacaoControlador = TextEditingController();
  String? mensagem;

  Salvar() {

    // Variveis
    String nome = _nomeControlador.text.trim();
    String email = _emailControlador.text.trim();
    String senha = _senhaControlador.text.trim();
    String senhaConfirmacao = _senhaConfirmacaoControlador.text.trim();

    // Validações
    // Validação do campo nome
    if(nome.isEmpty) {
      setState(() {
        mensagem = 'O campo nome é obrigatório!';
      });
      return;
    }
    if(nome.length < 3 || nome.length > 50) {
      setState(() {
        mensagem = 'O nome deve ter entre 3 e 50 caracteres';
      });
      return;
    }

    // Validação do campo email
    if(email.isEmpty) {
      setState(() {
        mensagem = 'O campo email é obrigatório!';
      });
      return;
    }
    // (r'Usuario[@ obrigatorio]dominio[\. deve ter ponto]A extenção do dominio deve ter pelo menos 2 caracteres')
    if(!RegExp(r'^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}$').hasMatch(email)) {
      setState(() {
        mensagem = 'O email deve ser válido. algo@dominio.extensao';
      });
      return;
    }

    // Validação do campo senha
    if(senha.isEmpty) {
      setState(() {
        mensagem = 'O campo senha é obrigatório!';
      });
      return;
    }
    if(senha.length < 6 || senha.length > 20) {
      setState(() {
        mensagem = 'A senha deve ter entre 6 e 20 caracteres';
      });
      return;
    }

    // Validação do campo senhaConfirmacao
    if(senhaConfirmacao.isEmpty) {
      setState(() {
        mensagem = 'O campo confirmação de senha é obrigatório!';
      });
      return;
    }
    if(senha != senhaConfirmacao) {
      setState(() {
        mensagem = 'A senha e a confirmação de senha devem ser iguais';
      });
      return;
    }

    setState(() {
      mensagem = 'Usuário cadastrado com sucesso';
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Exercício 6 - Cadastro de Usuários'),
      ),
      body: Padding(
        padding: EdgeInsets.all(25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 20,
            ),
            
            TextField(
              controller: _nomeControlador,
              decoration: InputDecoration(
                labelText: 'Digite o nome do usuário',
                hintText: 'Marcus Rocha',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _emailControlador,
              decoration: InputDecoration(
                labelText: 'Digite o email do usuário',
                hintText: 'marcus.rocha@example.com',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _senhaControlador,
              decoration: InputDecoration(
                labelText: 'Digite a senha do usuário',
                hintText: 'senhasecreta',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _senhaConfirmacaoControlador,
              decoration: InputDecoration(
                labelText: 'Confirme a senha do usuário',
                hintText: 'senhasecreta',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),

            SizedBox(
              height: 20,
            ),

            Text(
              mensagem ?? '',
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){Salvar();},
              child: Text('Cadastrar Usuário'),
            ),
          ],
        ),
      ),
    );
  }
}