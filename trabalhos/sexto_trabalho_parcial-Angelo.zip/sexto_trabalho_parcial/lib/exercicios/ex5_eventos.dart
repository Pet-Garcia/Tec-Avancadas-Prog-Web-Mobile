import 'package:flutter/material.dart';

class Ex5_EventosPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Ex5_EventosState();
  }
}

class Ex5_EventosState extends State<Ex5_EventosPage> {

  // Controllers para os campos de texto
  TextEditingController _nomeeventoControlador = TextEditingController();
  TextEditingController _minparticipantesControlador = TextEditingController();
  TextEditingController _maxparticipantesControlador = TextEditingController();
  TextEditingController _valorControlador = TextEditingController();
  String? mensagem;

  Salvar() {
    // Variaveis
    String nomeEvento = _nomeeventoControlador.text.trim();
    String minParticipantes = _minparticipantesControlador.text.trim();
    String maxParticipantes = _maxparticipantesControlador.text.trim();
    String valor = _valorControlador.text.trim();

    // Validações
    // Validação do campo nome
    if(nomeEvento.isEmpty) {
      setState(() {
        mensagem = 'O campo nome é obrigatório!';
      });
      return;
    }
    if(nomeEvento.length < 5 || nomeEvento.length > 100) {
      setState(() {
        mensagem = 'O nome deve ter entre 5 e 100 caracteres';
      });
      return;
    }

    // Validação do campo minparticipantes
    if(minParticipantes.isEmpty) {
      setState(() {
        mensagem = 'O campo mínimo de participantes é obrigatório!';
      });
      return;
    }
    int? minParticipantes_convertido = int.tryParse(minParticipantes);
    if(minParticipantes_convertido == null) {
      setState(() {
        mensagem = 'O mínimo de participantes deve ser um número inteiro';
      });
      return;
    }
    if(minParticipantes_convertido < 1) {
      setState(() {
        mensagem = 'O mínimo de participantes deve ser maior que 0';
      });
      return;
    }

    // Validação do campo maxparticipantes
    if(maxParticipantes.isEmpty) {
      setState(() {
        mensagem = 'O campo máximo de participantes é obrigatório!';
      });
      return;
    }
    int? maxParticipantes_convertido = int.tryParse(maxParticipantes);
    if(maxParticipantes_convertido == null) {
      setState(() {
        mensagem = 'O máximo de participantes deve ser um número inteiro';
      });
      return;
    }
    if(maxParticipantes_convertido < 1 || maxParticipantes_convertido > 50000) {
      setState(() {
        mensagem = 'O máximo de participantes deve estar entre 1 e 50 mil (50000)';
      });
      return;
    }
    if(maxParticipantes_convertido <= minParticipantes_convertido) {
      setState(() {
        mensagem = 'O máximo de participantes deve ser maior ou igual que o mínimo de participantes';
      });
      return;
    }

    // Validação do campo valor
    if(valor.isEmpty) {
      setState(() {
        mensagem = 'O campo valor é obrigatório!';
      });
      return;
    }
    if(!RegExp(r'^\d+([,.]\d{1,2})?$').hasMatch(valor)) {
      setState(() {
        mensagem = 'O valor deve ter no máximo duas casas decimais';
      });
      return;
    }
    double? valor_convertido = double.tryParse(valor.replaceAll(',','.'));
    if(valor_convertido == null) {
      setState(() {
        mensagem = 'Valor informado no campo valor é invalido!';
      });
      return;
    }
    if(valor_convertido < 0.00 || valor_convertido > 10000.00) {
      setState(() {
        mensagem = 'O valor deve estar entre 0,00 e 10 mil (10000,00)';
      });
      return;
    }

    // Validação de sucesso
    setState(() {
      mensagem = 'Evento salvo com sucesso';
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Exercício 5 - Cadastro de Eventos'),
      ),
      body: Padding(
        padding: EdgeInsets.all(25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 20,
            ),
            
            TextField(
              controller: _nomeeventoControlador,
              decoration: InputDecoration(
                labelText: 'Digite o nome do evento',
                hintText: 'Conferência de Flutter',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _minparticipantesControlador,
              decoration: InputDecoration(
                labelText: 'Digite o mínimo de participantes',
                hintText: '10',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _maxparticipantesControlador,
              decoration: InputDecoration(
                labelText: 'Digite o máximo de participantes',
                hintText: '1000',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            TextField(
              controller: _valorControlador,
              decoration: InputDecoration(
                labelText: 'Digite o valor do evento',
                hintText: '100,00',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            Text(
              mensagem ?? '',
            ),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: (){Salvar();},
              child: Text('Cadastrar Evento'),
            ),
          ],
        ),
      ),
    );
  }
}