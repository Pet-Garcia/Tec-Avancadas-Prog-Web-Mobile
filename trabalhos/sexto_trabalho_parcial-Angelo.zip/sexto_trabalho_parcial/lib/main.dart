import 'package:flutter/material.dart';
import 'package:sexto_trabalho_parcial/exercicios/paginainicial.dart';

void main() {
  runApp(const SextoApp());
}

class SextoApp extends StatelessWidget {
  const SextoApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sexto Trabalho Parcial',
      debugShowCheckedModeBanner: false,
      home: PaginaInicialPage(),
    );
  }
}