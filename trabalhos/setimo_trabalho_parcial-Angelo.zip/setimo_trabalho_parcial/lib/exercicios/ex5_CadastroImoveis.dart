import 'package:flutter/material.dart';

class Ex5_CadastroImoveisPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Ex5_CadastroImoveisState();
  }
}

class Ex5_CadastroImoveisState extends State<Ex5_CadastroImoveisPage> {
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  TextEditingController _enderecoController = TextEditingController();
  TextEditingController _numController = TextEditingController();
  TextEditingController _areaController = TextEditingController();
  TextEditingController _valorImovelController = TextEditingController();

  String? validarEndereco(String? valor) {
    if (valor == null || valor.isEmpty) {
      return 'O campo endereço é obrigatório!';
    }

    if (valor.length < 5 || valor.length > 100) {
      return 'O campo endereço deve ter entre 5 e 100 caracteres!';
    }

    return null;
  }

  String? validarNum(String? valor) {
    if (valor == null || valor.isEmpty) {
      return 'O campo número é obrigatório!';
    }

    int? num_convertido = int.tryParse(valor);

    if (num_convertido == null) {
      return 'O campo número deve ser um número inteiro';
    }

    if (num_convertido < 1 || num_convertido > 99999) {
      return 'O campo número deve estar entre 1 e 99999 horas';
    }

    return null;
  }

  String? validarArea(String? valor) {
    if (valor == null || valor.isEmpty) {
      return 'O campo carga horária é obrigatório!';
    }

    double? area_convertido = double.tryParse(valor.replaceAll(',', '.'));

    if(area_convertido == null){
      return 'Valor informado no campo área é invalido!';
    }

    if(!RegExp(r'^\d+([,.]\d{1,2})?$').hasMatch(valor)) {
      return 'A área deve ter no maximo duas casas decimais';
    }

    // Limita a quantidade minima e maxima permitida no sistema
    if(area_convertido < 10 || area_convertido > 10000) {
      return 'Valor informado no campo área deve estar entre 10 e 10000,00!'; // Para colocar o $ sem entrar em conflito com a configuração do Dart tem que ter a \ 
    }

    return null;
  }

  String? validarValorImovel(String? valor) {
    if (valor == null || valor.isEmpty) {
      return 'O campo valor do imovel é obrigatório!';
    }

    double? valorImovel_convertido = double.tryParse(valor.replaceAll(',', '.'));

    if(valorImovel_convertido == null){
      return 'Valor informado no campo valor do imovel é invalido!';
    }

    if(!RegExp(r'^\d+([,.]\d{1,2})?$').hasMatch(valor)) {
      return 'O valor do imovel deve ter no maximo duas casas decimais';
    }

    // Limita a quantidade minima e maxima permitida no sistema
    if(valorImovel_convertido < 20000 || valorImovel_convertido > 10000000) {
      return 'Valor informado no campo valor do imovel deve estar entre 20000 e 10000000,00!'; // Para colocar o $ sem entrar em conflito com a configuração do Dart tem que ter a \ 
    }

    return null;
  }

  void Salvar() {

    FormState? formularioEstado = formularioChave.currentState;

    if (formularioEstado == null || !formularioEstado.validate()) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Imovel cadastrado com sucesso!'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ex5 - Cadastro de Imovel'),
      ),
      body: Form(
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [
              TextFormField(
                controller: _enderecoController,
                decoration: InputDecoration(
                  labelText: 'Endereço do Imovel',
                  hintText: 'Ex: Alagoas',
                  border: OutlineInputBorder(),
                ),
                validator: validarEndereco,
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _numController,
                decoration: InputDecoration(
                  labelText: 'Número do endereço',
                  hintText: 'Ex: 12345',
                  border: OutlineInputBorder(),
                ),
                validator: validarNum,
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _areaController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Área do Endereço',
                  hintText: 'Ex: 80',
                  border: OutlineInputBorder(),
                ),
                validator: validarArea,
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _valorImovelController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Valor do Imovel',
                  hintText: 'Ex: 25000',
                  border: OutlineInputBorder(),
                ),
                validator: validarValorImovel,
              ),

              SizedBox(height: 20),

              ElevatedButton(
                onPressed: Salvar,
                child: Text('Salvar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}