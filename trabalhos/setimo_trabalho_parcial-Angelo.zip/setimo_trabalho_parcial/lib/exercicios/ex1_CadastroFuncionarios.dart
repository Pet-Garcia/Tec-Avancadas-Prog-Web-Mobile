import 'package:flutter/material.dart';

class Ex1_CadastroFuncionariosPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return Ex1_CadastroFuncionariosState();
  }
}

class Ex1_CadastroFuncionariosState extends State<Ex1_CadastroFuncionariosPage>{
  
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  TextEditingController _nomeController = TextEditingController();
  TextEditingController _idadeController = TextEditingController();
  TextEditingController _salarioController = TextEditingController();
  TextEditingController _dependentesController = TextEditingController();


  String? validarNome (String? valor) {
    if(valor == null || valor.isEmpty){
      return 'O campo nome é obrigatorio!';
    }

    if(valor.length < 3 || valor.length > 60){
      return 'O campo nome deve ter entre 3 a 60 caracteres!';
    }

    return null;
  }

  String? validarIdade (String? valor) {
    if(valor == null || valor.isEmpty){
      return 'O campo idade é obrigatorio';
    }

    int? idade_convertida = int.tryParse(valor);

    if(idade_convertida == null){
      return 'O campo idade deve ser um inteiro';
    }

    if(idade_convertida < 18 || idade_convertida > 100){
      return 'O campo idade deve estar entre 18 e 100';
    }

    return null;
  }

  String? validarSalario (String? valor) {
    if(valor == null || valor.isEmpty) {
      return 'O campo salario é obrigatório!';
    }

    // Tenta validar preco como double se não manda como vazio. Substitui todas as ',' por '.' para evitar erros de sistema
    double? salario_convertido = double.tryParse(valor.replaceAll(',', '.'));

    if(salario_convertido == null){
      return 'Valor informado no campo preço é invalido!';
    }

    if(!RegExp(r'^\d+([,.]\d{1,2})?$').hasMatch(valor)) {
      return 'O salario deve ter no maximo duas casas decimais';
    }

    // Limita a quantidade minima e maxima permitida no sistema
    if(salario_convertido < 1000 || salario_convertido > 50000) {
      return 'Valor informado no campo preco deve estar entre R\$ 1000 e R\$ 50000,00!'; // Para colocar o $ sem entrar em conflito com a configuração do Dart tem que ter a \ 
    }

    return null;
  }

  String? validarDependentes (String? valor) {
    if(valor == null || valor.isEmpty){
      return 'O campo dependentes é obrigatorio';
    }

    int? dependentes_convertida = int.tryParse(valor);

    if(dependentes_convertida == null){
      return 'O campo dependentes deve ser um inteiro';
    }

    if(dependentes_convertida < 0 || dependentes_convertida > 10){
      return 'O campo dependentes deve estar entre 0 e 10';
    }

    return null;
  }

  void Salvar() {

    // Pega o estado do formulario no momento
    FormState? formularioEstado = formularioChave.currentState;

    // Se o validate der true é salvo, se não ou se for nulo entra no if // !nome é o negativo ou não
    if(formularioEstado == null || !formularioEstado.validate()) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Funcionário cadastrado com sucesso!'),
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('Ex1 - Cadastro de Funcionarios'),
      ),

      body: Form(
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [

              TextFormField(
                controller: _nomeController,
                decoration: InputDecoration(
                  labelText: 'Insira o nome do Funcionario',
                  hintText: 'Ex: João Silva',
                  border: OutlineInputBorder(),
                ),
                validator: validarNome,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _idadeController,
                decoration: InputDecoration(
                  labelText: 'Insira a idade do Funcionario',
                  hintText: 'Ex: 25',
                  border: OutlineInputBorder(),
                ),
                validator: validarIdade,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _salarioController,
                decoration: InputDecoration(
                  labelText: 'Insira o salario do Funcionario',
                  hintText: 'Ex: 2500',
                  border: OutlineInputBorder(),
                ),
                validator: validarSalario,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _dependentesController,
                decoration: InputDecoration(
                  labelText: 'Insira o numero de dependentes do Funcionario',
                  hintText: 'Ex: 2',
                  border: OutlineInputBorder(),
                ),
                validator: validarDependentes,
              ),

              SizedBox(height: 20,),

              ElevatedButton(
                onPressed: (){Salvar();},
                child: Text('Salvar'),
              )
            ]
          )
        )
      )
    );

  }
}