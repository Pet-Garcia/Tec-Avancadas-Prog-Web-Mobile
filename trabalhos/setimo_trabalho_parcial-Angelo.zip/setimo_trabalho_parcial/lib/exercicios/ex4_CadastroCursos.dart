import 'package:flutter/material.dart';

class Ex4_CadastroCursosPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Ex4_CadastroCursosState();
  }
}

class Ex4_CadastroCursosState extends State<Ex4_CadastroCursosPage> {
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  TextEditingController _nomeCursoController = TextEditingController();
  TextEditingController _codigoCursoController = TextEditingController();
  TextEditingController _cargaHorariaController = TextEditingController();
  TextEditingController _numVagasController = TextEditingController();

  String? validarNome(String? valor) {
    if (valor == null || valor.isEmpty) {
      return 'O campo nome do curso é obrigatório!';
    }

    if (valor.length < 5 || valor.length > 100) {
      return 'O campo nome do curso deve ter entre 5 e 100 caracteres!';
    }

    return null;
  }

  String? validarCodigo(String? valor) {
    if (valor == null || valor.isEmpty) {
      return 'O campo código do curso é obrigatório!';
    }

    if(!RegExp(r'^[A-Za-z]{3}-\d{4}$').hasMatch(valor)) {
      return 'O código do curso deve seguir o formato CUR-1234';
    }

    return null;
  }

  String? validarCargaHoraria(String? valor) {
    if (valor == null || valor.isEmpty) {
      return 'O campo carga horária é obrigatório!';
    }

    int? cargaHoraria_convertida = int.tryParse(valor);

    if (cargaHoraria_convertida == null) {
      return 'O campo carga horária deve ser um número inteiro';
    }

    if (cargaHoraria_convertida < 20 || cargaHoraria_convertida > 2000) {
      return 'O campo carga horária deve estar entre 20 e 2000 horas';
    }

    return null;
  }

  String? validarNumVagas(String? valor) {
    if (valor == null || valor.isEmpty) {
      return 'O campo número de vagas é obrigatório!';
    }

    int? numeroVagas_connvertido = int.tryParse(valor);

    if (numeroVagas_connvertido == null) {
      return 'O campo número de vagas deve ser um número inteiro';
    }

    if (numeroVagas_connvertido < 1 || numeroVagas_connvertido > 500) {
      return 'O campo número de vagas deve estar entre 1 e 500';
    }

    return null;
  }

  void Salvar() {

    FormState? formularioEstado = formularioChave.currentState;

    if (formularioEstado == null || !formularioEstado.validate()) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Curso cadastrado com sucesso!'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ex4 - Cadastro de Cursos'),
      ),
      body: Form(
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [
              TextFormField(
                controller: _nomeCursoController,
                decoration: InputDecoration(
                  labelText: 'Nome do curso',
                  hintText: 'Ex: Desenvolvimento de Software',
                  border: OutlineInputBorder(),
                ),
                validator: validarNome,
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _codigoCursoController,
                decoration: InputDecoration(
                  labelText: 'Código do curso',
                  hintText: 'Ex: CUR-1234',
                  border: OutlineInputBorder(),
                ),
                validator: validarCodigo,
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _cargaHorariaController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Carga horária',
                  hintText: 'Ex: 80',
                  border: OutlineInputBorder(),
                ),
                validator: validarCargaHoraria,
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _numVagasController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Número de vagas',
                  hintText: 'Ex: 30',
                  border: OutlineInputBorder(),
                ),
                validator: validarNumVagas,
              ),

              SizedBox(height: 20),

              ElevatedButton(
                onPressed: Salvar,
                child: Text('Salvar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}