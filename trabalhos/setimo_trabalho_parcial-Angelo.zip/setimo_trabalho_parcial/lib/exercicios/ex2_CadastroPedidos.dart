import 'package:flutter/material.dart';

class Ex2_CadastroPedidosPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return Ex2_CadastroPedidosState();
  }
}

class Ex2_CadastroPedidosState extends State<Ex2_CadastroPedidosPage>{
  
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  TextEditingController _nomeController = TextEditingController();
  TextEditingController _valorController = TextEditingController();
  TextEditingController _quantidadeController = TextEditingController();
  TextEditingController _descontoController = TextEditingController();


  String? validarNome (String? valor) {
    if(valor == null || valor.isEmpty){
      return 'O campo nome é obrigatorio!';
    }

    if(valor.length < 3 || valor.length > 60){
      return 'O campo nome deve ter entre 3 a 60 caracteres!';
    }

    return null;
  }

  String? validarValor (String? valor) {
    if(valor == null || valor.isEmpty) {
      return 'O campo valor é obrigatório!';
    }

    // Tenta validar preco como double se não manda como vazio. Substitui todas as ',' por '.' para evitar erros de sistema
    double? valor_convertido = double.tryParse(valor.replaceAll(',', '.'));

    if(valor_convertido == null){
      return 'Valor informado no campo valor é invalido!';
    }

    if(!RegExp(r'^\d+([,.]\d{1,2})?$').hasMatch(valor)) {
      return 'O valor deve ter no maximo duas casas decimais';
    }

    // Limita a quantidade minima e maxima permitida no sistema
    if(valor_convertido < 1.0 || valor_convertido > 99999.99) {
      return 'Valor informado no campo valor deve estar entre R\$ 1,0 e R\$ 99.999,99!'; // Para colocar o $ sem entrar em conflito com a configuração do Dart tem que ter a \ 
    }

    return null;
  }

  String? validarQuantidade (String? valor) {
    if(valor == null || valor.isEmpty){
      return 'O campo quantidade é obrigatorio';
    }

    int? quantidade_convertida = int.tryParse(valor);

    if(quantidade_convertida == null){
      return 'O campo quantidade deve ser um inteiro';
    }

    if(quantidade_convertida < 1 || quantidade_convertida > 100){
      return 'O campo quantidade deve estar entre 18 e 100';
    }

    return null;
  }

  String? validarDesconto (String? valor) {
    if(valor == null || valor.isEmpty){
      return 'O campo desconto é obrigatorio';
    }

    int? desconto_convertida = int.tryParse(valor);

    if(desconto_convertida == null){
      return 'O campo desconto deve ser um inteiro';
    }

    if(desconto_convertida < 0 || desconto_convertida > 100){
      return 'O campo desconto deve estar entre 18 e 100';
    }

    return null;
  }

  void Salvar() {

    // Pega o estado do formulario no momento
    FormState? formularioEstado = formularioChave.currentState;

    // Se o validate der true é salvo, se não ou se for nulo entra no if // !nome é o negativo ou não
    if(formularioEstado == null || !formularioEstado.validate()) {
      return;
    }
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Pedido cadastrado com sucesso!'),
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('Ex2 - Cadastro de Pedidos'),
      ),

      body: Form(
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [

              TextFormField(
                controller: _nomeController,
                decoration: InputDecoration(
                  labelText: 'Insira o nome do Cliente',
                  hintText: 'Ex: Marcus Rocha',
                  border: OutlineInputBorder(),
                ),
                validator: validarNome,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _valorController,
                decoration: InputDecoration(
                  labelText: 'Insira o valor do pedido',
                  hintText: 'Ex: 150',
                  border: OutlineInputBorder(),
                ),
                validator: validarValor,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _quantidadeController,
                decoration: InputDecoration(
                  labelText: 'Insira a quantidade de itens do pedido',
                  hintText: 'Ex: 25',
                  border: OutlineInputBorder(),
                ),
                validator: validarQuantidade,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _descontoController,
                decoration: InputDecoration(
                  labelText: 'Insira o valor do desconto',
                  hintText: 'Ex: 15',
                  border: OutlineInputBorder(),
                ),
                validator: validarDesconto,
              ),

              SizedBox(height: 20,),

              ElevatedButton(
                onPressed: (){Salvar();},
                child: Text('Salvar'),
              )
            ]
          )
        )
      )
    );

  }
}