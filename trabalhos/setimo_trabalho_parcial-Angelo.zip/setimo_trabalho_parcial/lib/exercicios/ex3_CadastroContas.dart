import 'package:flutter/material.dart';

class Ex3_CadastroContasPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return Ex3_CadastroContasState();
  }
}

class Ex3_CadastroContasState extends State<Ex3_CadastroContasPage>{
  
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  TextEditingController _nomeController = TextEditingController();
  TextEditingController _numBancoController = TextEditingController();
  TextEditingController _agenciaController = TextEditingController();
  TextEditingController _numContaController = TextEditingController();
  TextEditingController _saldoInicialController = TextEditingController();


  String? validarNome (String? valor) {
    if(valor == null || valor.isEmpty){
      return 'O campo nome é obrigatorio!';
    }

    if(valor.length < 3 || valor.length > 80){
      return 'O campo nome deve ter entre 3 a 80 caracteres!';
    }

    return null;
  }

  String? validarNumBanco (String? valor) {
    if(valor == null || valor.isEmpty){
      return 'O campo numero do banco é obrigatorio';
    }

    int? numeroBanco_convertida = int.tryParse(valor);

    if(numeroBanco_convertida == null){
      return 'O campo numero do banco deve ser um inteiro';
    }

    if(valor.length == 3){
      return 'O campo numero do banco deve ter 3 digitos';
    }

    return null;
  }

  String? validarAgencia (String? valor) {
    if(valor == null || valor.isEmpty){
      return 'O campo agencia é obrigatorio';
    }

    int? agencia_convertida = int.tryParse(valor);

    if(agencia_convertida == null){
      return 'O campo agencia deve ser um inteiro';
    }

    if(valor.length < 4 || valor.length > 5){
      return 'O campo agencia deve ter entre 4 ou 5 digitos';
    }

    return null;
  }

  String? validarNumConta (String? valor) {
    if(valor == null || valor.isEmpty){
      return 'O campo numero da conta é obrigatorio';
    }

    int? numConta_convertida = int.tryParse(valor);

    if(numConta_convertida == null){
      return 'O campo numero da conta deve ser um inteiro';
    }

    if(valor.length < 0 || valor.length > 10){
      return 'O campo numero da conta deve estar entre 5 e 10 digitos';
    }

    return null;
  }

  String? validarSaldo (String? valor) {
    if(valor == null || valor.isEmpty) {
      return 'O campo saldo incial é obrigatório!';
    }

    // Tenta validar preco como double se não manda como vazio. Substitui todas as ',' por '.' para evitar erros de sistema
    double? saldo_convertido = double.tryParse(valor.replaceAll(',', '.'));

    if(saldo_convertido == null){
      return 'Valor informado no campo preço é invalido!';
    }

    if(!RegExp(r'^\d+([,.]\d{1,2})?$').hasMatch(valor)) {
      return 'O saldo deve ter no maximo duas casas decimais';
    }

    // Limita a quantidade minima e maxima permitida no sistema
    if(saldo_convertido < 0 || saldo_convertido > 1000000) {
      return 'Valor informado no campo saldo deve estar entre R\$ 0 e R\$ 1000000,00!'; // Para colocar o $ sem entrar em conflito com a configuração do Dart tem que ter a \ 
    }

    return null;
  }

  void Salvar() {

    // Pega o estado do formulario no momento
    FormState? formularioEstado = formularioChave.currentState;

    // Se o validate der true é salvo, se não ou se for nulo entra no if // !nome é o negativo ou não
    if(formularioEstado == null || !formularioEstado.validate()) {
      return;
    }
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Conta Bancaria cadastrado com sucesso!'),
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('Ex1 - Cadastro de Funcionarios'),
      ),

      body: Form(
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [

              TextFormField(
                controller: _nomeController,
                decoration: InputDecoration(
                  labelText: 'Insira o nome do Cliente',
                  hintText: 'Ex: João Silva',
                  border: OutlineInputBorder(),
                ),
                validator: validarNome,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _numBancoController,
                decoration: InputDecoration(
                  labelText: 'Insira o numero do banco',
                  hintText: 'Ex: 255',
                  border: OutlineInputBorder(),
                ),
                validator: validarNumBanco,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _agenciaController,
                decoration: InputDecoration(
                  labelText: 'Insira o numero da agencia',
                  hintText: 'Ex: 2500',
                  border: OutlineInputBorder(),
                ),
                validator: validarAgencia,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _numContaController,
                decoration: InputDecoration(
                  labelText: 'Insira o numero da conta do Cliente',
                  hintText: 'Ex: 244455',
                  border: OutlineInputBorder(),
                ),
                validator: validarNumConta,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _saldoInicialController,
                decoration: InputDecoration(
                  labelText: 'Insira o saldo inicial da conta do Cliente',
                  hintText: 'Ex: 1000',
                  border: OutlineInputBorder(),
                ),
                validator: validarSaldo,
              ),

              SizedBox(height: 20,),

              ElevatedButton(
                onPressed: (){Salvar();},
                child: Text('Salvar'),
              )
            ]
          )
        )
      )
    );

  }
}