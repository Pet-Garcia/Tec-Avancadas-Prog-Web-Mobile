import 'package:flutter/material.dart';
import 'package:validatorless/validatorless.dart';
import 'package:intl/intl.dart';
import 'package:all_br_forms/all_br_forms.dart';

class Ex5_CadastroImoveisPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Ex5_CadastroImoveisState();
  }
}

class Ex5_CadastroImoveisState extends State<Ex5_CadastroImoveisPage> {
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  TextEditingController _nomeProprietarioController = TextEditingController();
  TextEditingController _cpfProprietarioController = TextEditingController();
  TextEditingController _cepController = TextEditingController();
  TextEditingController _enderecoController = TextEditingController();
  TextEditingController _numController = TextEditingController();
  TextEditingController _areaController = TextEditingController();
  TextEditingController _valorImovelController = TextEditingController();


  void Salvar() {

    FormState? formularioEstado = formularioChave.currentState;

    if (formularioEstado == null || !formularioEstado.validate()) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Imóvel cadastrado com sucesso!'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ex5 - Cadastro de Imovel'),
      ),
      body: Form(
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [
              TextFormField(
                controller: _nomeProprietarioController,
                decoration: InputDecoration(
                  labelText: 'Nome do proprietário',
                  hintText: 'Ex: João Silva',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo nome é obrigatório!'),
                  Validatorless.min(3, 'O campo nome deve ter no mínimo 3 caracteres!'),
                  Validatorless.max(80, 'O campo nome deve ter no máximo 80 caracteres!'),
                ]),
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _cpfProprietarioController,
                decoration: InputDecoration(
                  labelText: 'CPF do proprietário',
                  hintText: 'Ex: 123.456.789-00',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  CpfMask(),
                ],
                validator: Validatorless.multiple([
                  Validatorless.required('O campo CPF é obrigatório!'),
                  Validatorless.min(14, 'O campo deve ter 14 caracteres!'),
                ]),
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _cepController,
                decoration: InputDecoration(
                  labelText: 'CEP',
                  hintText: 'Ex: 12345-678',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  CepMask(),
                ],
                validator: Validatorless.multiple([
                  Validatorless.required('O campo CEP é obrigatório!'),
                ]),
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _enderecoController,
                decoration: InputDecoration(
                  labelText: 'Endereço do Imovel',
                  hintText: 'Ex: Rua das Alagoas',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo endereço é obrigatório!'),
                  Validatorless.min(5, 'O campo endereço deve ter entre 5 a 100 caracteres!'),
                  Validatorless.max(100, 'O campo endereço deve ter entre 5 a 100 caracteres!'),
                ]),
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _numController,
                decoration: InputDecoration(
                  labelText: 'Número do endereço',
                  hintText: 'Ex: 123',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo número do endereço é obrigatório!'),
                  Validatorless.regex(
                    RegExp(r'^\d+$'), 
                    'O campo deve ser um número inteiro!'
                  ),
                  Validatorless.numbersBetweenInterval(
                    1,
                    99999,
                    'O campo número do endereço deve estar entre 1 e 99.999!',
                  ),
                ]),
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _areaController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Área do Imovel',
                  hintText: 'Ex: 80',
                  border: OutlineInputBorder(),
                ),
                validator: (valor) {
                  // Converte primeiro
                  String valorConvertido = valor?.replaceAll(',', '.') ?? '';

                  // Faz as validações
                  return Validatorless.multiple([
                    Validatorless.required(
                      'O campo área é obrigatório!',
                    ),
                    Validatorless.regex(
                      RegExp(r'^\d+([,.]\d{1,2})?$'),
                      'A área deve ter no máximo 2 casas decimais!',
                    ),
                    Validatorless.numbersBetweenInterval(
                      10,
                      10000,
                      'O campo deve estar entre 10,00 e 10.000,00!',
                    ),
                  ])(valorConvertido);
                },
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _valorImovelController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Valor do Imovel',
                  hintText: 'Ex: 250000',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  CurrencyMask(),
                ],
                validator: (valor) {
                  // Retira o que a mascara passa para o numberBetweenInterval
                  String valorConvertido = valor
                          ?.replaceAll('R\$ ', '')
                          .replaceAll('.', '')
                          .replaceAll(',', '.') ??
                      '';

                  return Validatorless.multiple([
                    Validatorless.required(
                      'O campo capital social é obrigatório!',
                    ),
                    Validatorless.numbersBetweenInterval(
                      20000,
                      100000000,
                      'O campo deve estar entre R\$ 20.000,00 e R\$ 100.000.000,00!',
                    ),
                  ])(valorConvertido);
                },
              ),

              SizedBox(height: 20),

              ElevatedButton(
                onPressed: Salvar,
                child: Text('Salvar'),
              ),
            ],
          ),
        ),
      ),
    );
    
  }
}