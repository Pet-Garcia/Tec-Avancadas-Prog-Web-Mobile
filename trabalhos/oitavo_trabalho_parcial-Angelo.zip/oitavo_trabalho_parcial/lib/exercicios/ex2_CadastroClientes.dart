import 'package:flutter/material.dart';
import 'package:validatorless/validatorless.dart';
import 'package:intl/intl.dart';
import 'package:all_br_forms/all_br_forms.dart';

class Ex2_CadastroClientesPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return Ex2_CadastroClientesState();
  }
}

class Ex2_CadastroClientesState extends State<Ex2_CadastroClientesPage>{
  
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  TextEditingController _nomeController = TextEditingController();
  TextEditingController _cpfController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _telefoneController = TextEditingController();
  TextEditingController _dataNascimentoController = TextEditingController();

  void Salvar() {

    // Pega o estado do formulario no momento
    FormState? formularioEstado = formularioChave.currentState;

    // Se o validate der true é salvo, se não ou se for nulo entra no if // !nome é o negativo ou não
    if(formularioEstado == null || !formularioEstado.validate()) {
      return;
    }
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Cliente cadastrado com sucesso!'),
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('Ex2 - Cadastro de Clientes'),
      ),

      body: Form(
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [

              TextFormField(
                controller: _nomeController,
                decoration: InputDecoration(
                  labelText: 'Insira o nome do Cliente',
                  hintText: 'Ex: Marcus Rocha',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo nome é obrigatório!'),
                  Validatorless.min(3, 'O campo nome deve ter entre 3 a 80 caracteres!'),
                  Validatorless.max(80, 'O campo nome deve ter entre 3 a 80 caracteres!'),
                ]),
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _cpfController,
                decoration: InputDecoration(
                  labelText: 'Insira o CPF do Cliente',
                  hintText: 'Ex: 123.456.789-00',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  CpfMask(),
                ],
                validator: Validatorless.multiple([
                  Validatorless.required('O campo CPF é obrigatório!'),
                  Validatorless.min(14, 'O campo deve ter 14 caracteres!'),
                ]),
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Insira o email do Cliente',
                  hintText: 'Ex: marcus.rocha@email.com',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo email é obrigatório!'),
                  Validatorless.email('Digite um email valido!'),
                ]),
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _telefoneController,
                decoration: InputDecoration(
                  labelText: 'Insira o telefone do Cliente',
                  hintText: 'Ex: (11) 91234-5678',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  PhoneMask(),
                ],
                validator: Validatorless.multiple([
                  Validatorless.required('O campo telefone é obrigatório'),
                  Validatorless.phone('O número de telefone deve ser valido!'),
                ]),
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _dataNascimentoController,
                decoration: InputDecoration(
                  labelText: 'Insira a data de nascimento do Cliente',
                  hintText: 'Ex: 01/01/1990',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  DateMask(),
                ],
                validator: Validatorless.multiple([
                  Validatorless.required('O campo data de nascimento é obrigatório!'),
                  (valor) {
                    if (valor == null || valor.isEmpty) {
                      return null;
                    }

                    try {
                      DateTime nascimento = DateFormat('dd/MM/yyyy').parseStrict(valor);

                      DateTime atual = DateTime.now();

                      int idade = atual.year - nascimento.year;

                      if (atual.month < nascimento.month || (atual.month == nascimento.month && atual.day < nascimento.day)) {
                        idade--;
                      }

                      if (idade < 18) {
                        return 'O cliente deve ter pelo menos 18 anos!';
                      }

                      return null;
                    } catch (e) {
                      return 'Digite uma data válida no formato dd/MM/yyyy!';
                    }
                  },
                ]),
              ),

              SizedBox(height: 20,),

              ElevatedButton(
                onPressed: (){Salvar();},
                child: Text('Salvar'),
              )
            ]
          )
        )
      )
    );

  }
}