import 'package:flutter/material.dart';
import 'package:validatorless/validatorless.dart';
import 'package:intl/intl.dart';
import 'package:all_br_forms/all_br_forms.dart';

class Ex1_CadastroFuncionariosPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return Ex1_CadastroFuncionariosState();
  }
}

class Ex1_CadastroFuncionariosState extends State<Ex1_CadastroFuncionariosPage>{
  
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  TextEditingController _nomeController = TextEditingController();
  TextEditingController _cpfController = TextEditingController();
  TextEditingController _idadeController = TextEditingController();
  TextEditingController _salarioController = TextEditingController();
  TextEditingController _dependentesController = TextEditingController();

  void Salvar() {

    // Pega o estado do formulario no momento
    FormState? formularioEstado = formularioChave.currentState;

    // Se o validate der true é salvo, se não ou se for nulo entra no if // !nome é o negativo ou não
    if(formularioEstado == null || !formularioEstado.validate()) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Funcionário cadastrado com sucesso!'),
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('Ex1 - Cadastro de Funcionarios'),
      ),

       body: Form(
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [

              TextFormField(
                controller: _nomeController,
                decoration: InputDecoration(
                  labelText: 'Insira o nome do Funcionario',
                  hintText: 'Ex: João Silva',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo nome é obrigatório!'),
                  Validatorless.min(3, 'O campo nome deve ter no mínimo 3 caracteres!'),
                  Validatorless.max(60, 'O campo nome deve ter no máximo 60 caracteres!'),
                ]),
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _cpfController,
                decoration: InputDecoration(
                  labelText: 'Insira o CPF do Funcionario',
                  hintText: 'Ex: 123.456.789-00',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  CpfMask(),
                ],
                validator: Validatorless.multiple([
                  Validatorless.required('O campo CPF é obrigatório!'),
                  Validatorless.min(14, 'O campo deve ter 14 caracteres!'),
                ]),
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _idadeController,
                decoration: InputDecoration(
                  labelText: 'Insira a idade do Funcionario',
                  hintText: 'Ex: 25',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo idade e obrigatório!'),
                  Validatorless.regex(
                    RegExp(r'^\d+$'), 
                    'O campo deve ser um número inteiro!'
                  ),
                  Validatorless.numbersBetweenInterval(
                    18,
                    100,
                    'O campo idade deve estar entre 18 e 100!',
                  ),
                ]),
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _salarioController,
                decoration: InputDecoration(
                  labelText: 'Insira o salario do Funcionario',
                  hintText: 'Ex: 2500',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  CurrencyMask(),
                ],
                validator: (valor) {
                  // Retira o que a mascara passa para o numberBetweenInterval
                  String valorConvertido = valor
                          ?.replaceAll('R\$ ', '')
                          .replaceAll('.', '')
                          .replaceAll(',', '.') ??
                      '';

                  return Validatorless.multiple([
                    Validatorless.required(
                      'O campo capital social é obrigatório!',
                    ),
                    Validatorless.numbersBetweenInterval(
                      1000,
                      100000000,
                      'O campo deve estar entre R\$ 1.000,00 e R\$ 100.000.000,00!',
                    ),
                  ])(valorConvertido);
                }
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _dependentesController,
                decoration: InputDecoration(
                  labelText: 'Insira o numero de dependentes do Funcionario',
                  hintText: 'Ex: 2',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo dependentes é obrigatório!'),
                  Validatorless.regex(
                    RegExp(r'^\d+$'), 
                    'O campo deve ser um número!'
                  ),
                  Validatorless.numbersBetweenInterval(
                    0,
                    10,
                    'O campo deve estar entre 0 e 10 dependentes'
                  ),
                ]),
              ),

              SizedBox(height: 20,),

              ElevatedButton(
                onPressed: (){Salvar();},
                child: Text('Salvar'),
              )
            ]
          )
        )
      )
    );

  }
}