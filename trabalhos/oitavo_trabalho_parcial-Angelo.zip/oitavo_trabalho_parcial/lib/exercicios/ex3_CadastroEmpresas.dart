import 'package:flutter/material.dart';
import 'package:validatorless/validatorless.dart';
import 'package:intl/intl.dart';
import 'package:all_br_forms/all_br_forms.dart';

class Ex3_CadastroEmpresasPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return Ex3_CadastroEmpresasState();
  }
}

class Ex3_CadastroEmpresasState extends State<Ex3_CadastroEmpresasPage>{
  
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  TextEditingController _razaoSocialController = TextEditingController();
  TextEditingController _cnpjController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _telefoneController = TextEditingController();
  TextEditingController _capitalSocialController = TextEditingController();

  void Salvar() {

    // Pega o estado do formulario no momento
    FormState? formularioEstado = formularioChave.currentState;

    // Se o validate der true é salvo, se não ou se for nulo entra no if // !nome é o negativo ou não
    if(formularioEstado == null || !formularioEstado.validate()) {
      return;
    }
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Empresa cadastrado com sucesso!'),
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('Ex3 - Cadastro de Empresas'),
      ),

      body: Form(
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [

              TextFormField(
                controller: _razaoSocialController,
                decoration: InputDecoration(
                  labelText: 'Insira a razao social da Empresa',
                  hintText: 'Ex: Silva Comercio de Alimentos Ltda',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo razão social é obrigatório!'),
                  Validatorless.min(3, 'O campo deve ter entre 3 a 100 caracteres!'),
                  Validatorless.max(100, 'O campo deve ter entre 3 a 100 caracteres!'),
                ])
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _cnpjController,
                decoration: InputDecoration(
                  labelText: 'Insira o CNPJ da Empresa',
                  hintText: 'Ex: 12.345.678/0001-90',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  CnpjMask(),
                ],
                validator: Validatorless.multiple([
                  Validatorless.required('O campo CNPJ é obrigatório!'),
                  Validatorless.min(18, 'O CNPJ deve estar completo!')
                ])
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Insira o e-mail da Empresa',
                  hintText: 'Ex: contato@empresa.com',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo email é obrigatório!'),
                  Validatorless.email('Digite um email valido!'),
                ]),
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _telefoneController,
                decoration: InputDecoration(
                  labelText: 'Insira o telefone da Empresa',
                  hintText: 'Ex: (11) 91234-5678',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  PhoneMask(),
                ],
                validator: Validatorless.multiple([
                  Validatorless.required('O campo telefone é obrigatório'),
                  Validatorless.phone('O número de telefone deve ser valido!'),
                ]),
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _capitalSocialController,
                decoration: InputDecoration(
                  labelText: 'Insira o valor do capital social da Empresa',
                  hintText: 'Ex: 50.000',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  CurrencyMask(),
                ],
                validator: (valor) {
                  // Retira o que a mascara passa para o numberBetweenInterval
                  String valorConvertido = valor
                          ?.replaceAll('R\$ ', '')
                          .replaceAll('.', '')
                          .replaceAll(',', '.') ??
                      '';

                  return Validatorless.multiple([
                    Validatorless.required(
                      'O campo capital social é obrigatório!',
                    ),
                    Validatorless.numbersBetweenInterval(
                      1000,
                      100000000,
                      'O campo deve estar entre R\$ 1.000,00 e R\$ 100.000.000,00!',
                    ),
                  ])(valorConvertido);
                }
              ),

              SizedBox(height: 20,),

              ElevatedButton(
                onPressed: (){Salvar();},
                child: Text('Salvar'),
              )
            ]
          )
        )
      )
    );

  }
}