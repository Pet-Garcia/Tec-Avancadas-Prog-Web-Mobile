import 'package:flutter/material.dart';
import 'package:validatorless/validatorless.dart';
import 'package:intl/intl.dart';
import 'package:all_br_forms/all_br_forms.dart';

class Ex4_CadastroCursosPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return Ex4_CadastroCursosState();
  }
}

class Ex4_CadastroCursosState extends State<Ex4_CadastroCursosPage> {
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  TextEditingController _nomeCursoController = TextEditingController();
  TextEditingController _descricaoController = TextEditingController();
  TextEditingController _emailResponsavelController = TextEditingController();
  TextEditingController _dataInicioController = TextEditingController();
  TextEditingController _numVagasController = TextEditingController();
  TextEditingController _mensalidadeController = TextEditingController();


  void Salvar() {

    FormState? formularioEstado = formularioChave.currentState;

    if (formularioEstado == null || !formularioEstado.validate()) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Curso cadastrado com sucesso!'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ex4 - Cadastro de Cursos'),
      ),
      body: Form(
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [
              TextFormField(
                controller: _nomeCursoController,
                decoration: InputDecoration(
                  labelText: 'Nome do curso',
                  hintText: 'Ex: Desenvolvimento de Software',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo nome do curso é obrigatório!'),
                  Validatorless.min(5, 'O campo nome do curso deve ter entre 5 a 100 caracteres!'),
                  Validatorless.max(100, 'O campo nome do curso deve ter entre 5 a 100 caracteres!'),
                ]),
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _descricaoController,
                decoration: InputDecoration(
                  labelText: 'Descrição do curso',
                  hintText: 'Ex: Curso voltado para iniciantes em programação',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo descrição é obrigatório!'),
                  Validatorless.min(10, 'O campo descrição deve ter entre 10 a 500 caracteres!'),
                  Validatorless.max(500, 'O campo descrição deve ter entre 10 a 500 caracteres!'),
                ]),
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _emailResponsavelController,
                decoration: InputDecoration(
                  labelText: 'E-mail do responsável',
                  hintText: 'Ex: responsavel@instituicao.com',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo email é obrigatório!'),
                  Validatorless.email('Digite um email valido!'),
                ]),
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _dataInicioController,
                decoration: InputDecoration(
                  labelText: 'Data de início',
                  hintText: 'Ex: 01/03/2026',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  DateMask(),
                ],
                validator: Validatorless.multiple([
                  Validatorless.required('O campo data de inicio é obrigatório!'),
                  (valor) {
                    if (valor == null || valor.isEmpty) {
                      return null;
                    }

                    try {
                      DateTime inicio = DateFormat('dd/MM/yyyy').parseStrict(valor);

                      DateTime atual = DateTime.now();

                      if (inicio.isBefore(atual)) {
                        return 'A data não pode ser anterior a atual!';
                      }

                      return null;
                    } catch (e) {
                      return 'Digite uma data válida no formato dd/MM/yyyy!';
                    }
                  },
                ]),
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _numVagasController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Número de vagas',
                  hintText: 'Ex: 30',
                  border: OutlineInputBorder(),
                ),
                validator: Validatorless.multiple([
                  Validatorless.required('O campo número de vagas é obrigatório!'),
                  Validatorless.regex(
                    RegExp(r'^\d+$'), 
                    'O campo deve ser um número inteiro!'
                  ),
                  Validatorless.numbersBetweenInterval(
                    1,
                    500,
                    'O campo número de vagas deve estar entre 1 e 500!',
                  ),
                ]),
              ),

              SizedBox(height: 20),

              TextFormField(
                controller: _mensalidadeController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Mensalidade',
                  hintText: 'Ex: 350',
                  border: OutlineInputBorder(),
                ),
                inputFormatters: [
                  CurrencyMask(),
                ],
                validator: (valor) {
                  // Retira o que a mascara passa para o numberBetweenInterval
                  String valorConvertido = valor
                          ?.replaceAll('R\$ ', '')
                          .replaceAll('.', '')
                          .replaceAll(',', '.') ??
                      '';

                  return Validatorless.multiple([
                    Validatorless.required(
                      'O campo capital social é obrigatório!',
                    ),
                    Validatorless.numbersBetweenInterval(
                      50,
                      10000,
                      'O campo deve estar entre R\$ 50,00 e R\$ 10.000,00!',
                    ),
                  ])(valorConvertido);
                }
              ),

              SizedBox(height: 20),

              ElevatedButton(
                onPressed: Salvar,
                child: Text('Salvar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}