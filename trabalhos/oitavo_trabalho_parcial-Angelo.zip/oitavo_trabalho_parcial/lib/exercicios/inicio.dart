import 'package:flutter/material.dart';
import 'package:oitavo_trabalho_parcial/exercicios/ex1_CadastroFuncionarios.dart';
import 'package:oitavo_trabalho_parcial/exercicios/ex2_CadastroClientes.dart';
import 'package:oitavo_trabalho_parcial/exercicios/ex3_CadastroEmpresas.dart';
import 'package:oitavo_trabalho_parcial/exercicios/ex4_CadastroCursos.dart';
import 'package:oitavo_trabalho_parcial/exercicios/ex5_CadastroImoveis.dart';

class InicioPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return InicioState();
  }
}

class InicioState extends State<InicioPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Página Inicial'),
      ),
      body: Padding(
        padding: EdgeInsets.all(25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex1_CadastroFuncionariosPage())
                );
              },
              child: Text('Exercício 1 - Cadastro de Funcionarios'),
            ),

            SizedBox(height: 20,),

            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex2_CadastroClientesPage())
                );
              },
              child: Text('Exercício 2 - Cadastro de Clientes'),
            ),

            SizedBox(height: 20,),

            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex3_CadastroEmpresasPage())
                );
              },
              child: Text('Exercício 3 - Cadastro de Empresas'),
            ),

            SizedBox(height: 20,),

            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex4_CadastroCursosPage())
                );
              },
              child: Text('Exercício 4 - Cadastro de Cursos'),
            ),

            SizedBox(height: 20,),

            ElevatedButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Ex5_CadastroImoveisPage())
                );
              },
              child: Text('Exercício 5 - Cadastro de Imoveis'),
            ),
          ]
        )
      )
    );
  }
}