import 'package:flutter/material.dart';
import 'package:oitavo_trabalho_parcial/exercicios/inicio.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Oitavo Trabalho Parcial',
      debugShowCheckedModeBanner: false,
      home: InicioPage(),
    );
  }
}