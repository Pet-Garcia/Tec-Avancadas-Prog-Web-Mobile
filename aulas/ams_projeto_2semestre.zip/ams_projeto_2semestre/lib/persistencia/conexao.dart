// Arquivo para fins didaticos
// Para descobrir sobre uma biblioteca gratuita de flutter tem o site: pub.dev
import 'package:supabase/supabase.dart';

void main() {
  print('Tentando conectar');
  SupabaseClient cliente = SupabaseClient (
    'https://oaywwuajjaegyqnafzhz.supabase.co', //URL
    'sb_publishable_5uUUYhC1k3W9d7Y8En2J2Q_cWyC_Ct4' //SENHA
  );
  print('Conexão estabelecida com sucesso');

}