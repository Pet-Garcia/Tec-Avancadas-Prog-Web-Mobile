// Para descobrir sobre uma biblioteca gratuita de flutter tem o site: pub.dev
import 'package:supabase/supabase.dart';

void main() {
  print('Tentando conectar');
  SupabaseClient cliente = SupabaseClient (
    'https://oaywwuajjaegyqnafzhz.supabase.co', //URL
    'sb_publishable_5uUUYhC1k3W9d7Y8En2J2Q_cWyC_Ct4' //SENHA
  );
  print('Conexão estabelecida com sucesso');

  //cliente.from('produtos'); //Passando o nome da tabela que vai ser utilizada
  //Uma lista de mapas(produtos com nome, preco e quantidade)
  List<Map<String, dynamic>> salvo = cliente.from('produtos').insert({ //Inserir os valores em formato de MAPA. Metodo que o flutter utiliza para facilitar o JSON (JSON = MAP). MAP<String, dynamic> tipo mapa, com uma valor String ('preco') e um valor dinamico (12.50)
    'nome': 'Coca Cola',
    'preco': 12.50,
    'quantidade': 15,
  }).select(); //Para evitar erros de duplicação 
}