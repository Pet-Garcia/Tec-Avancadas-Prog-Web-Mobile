// A pasta validadores é a nova, aplicando conteudo novo
import 'package:flutter/material.dart';

class ProdutoPage extends StatefulWidget{
  // @override createState
  @override
  State<StatefulWidget> createState() {
    return ProdutoState();
  }
}

class ProdutoState extends State<ProdutoPage>{
  TextEditingController _nomeControlador = TextEditingController();
  TextEditingController _precoControlador = TextEditingController();
  TextEditingController _quantidadeControlador = TextEditingController();

  // GlobalKey é obrigatorio receber um state<State>(ProdutoState(nome do state) ou FormState)
  // Torna o formulario reativo/funcional
  GlobalKey<FormState> formularioChave = GlobalKey<FormState>();

  String mensagem = ''; // String? = String opcional

  // Método de validação é obrigatoriamente uma string opcional
  String? validarNome (String? valor) {
    // return '' ou 'Mensagem' siginfica para o Flutter que há algo errado e foi enviado uma mensagem de volta
    // return null; Significa para o Flutter que está certo

    // O Flutter exige que seja considerado o valor se ele for null
    if(valor == null || valor.isEmpty) {
      return 'O campo nome é obrigatório!';
    }

    if(valor.length < 3 || valor.length > 50) {
      return 'O nome deve ter entre 3 e 50 caracteres';
    }

    return null;
  }

  String? validarPreco (String? valor) {
    if(valor == null || valor.isEmpty) {
      return 'O campo preço é obrigatório!';
    }

    // Tenta validar preco como double se não manda como vazio. Substitui todas as ',' por '.' para evitar erros de sistema
    double? preco_convertido = double.tryParse(valor.replaceAll(',', '.'));

    if(preco_convertido == null){
      return 'Valor informado no campo preço é invalido!';
    }

    if(!RegExp(r'^\d+([,.]\d{1,2})?$').hasMatch(valor)) {
      return 'O preco deve ter no maximo duas casas decimais';
    }

    // Limita a quantidade minima e maxima permitida no sistema
    if(preco_convertido < 0.10 || preco_convertido > 1000) {
      return 'Valor informado no campo preco deve estar entre R\$ 0,10 e R\$ 1000,00!'; // Para colocar o $ sem entrar em conflito com a configuração do Dart tem que ter a \ 

    }

    return null;
  }

  String? validarQuantidade (String? valor) {
    // Nulo de String
     if(valor == null || valor.isEmpty) {
      return 'O campo quantidade é obrigatório!';
    }

    // Tenta validar como int, se não o campo fica como vazio e envia uma mensagem informando
    int? quantidade_convertida = int.tryParse(valor);

    // Nulo de int
    if(quantidade_convertida == null){
      return 'Valor informado no campo quantidade é invalido!';
    }

    // Limita a quantidade minima e maxima dos produtos
    if(quantidade_convertida <= 0 || quantidade_convertida > 100) {
      return 'Valor informado no campo quantidade deve estar entre 1 e 100!';
    }

    return null;
  }

  void Salvar() {
    // Pega o estado do formulario no momento
    FormState? formularioEstado = formularioChave.currentState;

    // Se o validate der true é salvo, se não ou se for nulo entra no if // !nome é o negativo ou não
    if(formularioEstado == null || !formularioEstado.validate()) {

    }

    // Do antigo  
      // tipo var descobre automaticamente o tipo da variavel pelo numero que está sendo jogado nela. Pode haver erro dependendo do caso
      // Substituido o controlador do nome pelo validarNome       // ,trim impede que espaço em branco(" ") seja considerado como not empty
      // Para evitar erros de validação(tipo errado) primeira é dado em String o Text

    

    // RegExp é uma classe do dart para uma expressão regular(formula)
    // r'' significa que vai ter um texto dentro que deve igualar o preco
    // r'^ significa inicio - $' significa fim
    // \d significa que vai escrever um digito. + um ou mais digitos
    // ()? o que esta dentro do parentese é opcional(indicado pelo ?). [] significa que o que está dentro pode ser um ou outro dos caracteres dentro
    // \d+ significa infitas casas para frente. \d{} siginifica que está sendo limitado o conteudo pela quantidade de caracteres que está dentro do {}. { n, n} pode ser um ou outro
    

    


   

    setState(() {
      mensagem = 'Produto salvo com sucesso!';
    });
  }

  // @override build
  @override Widget build(BuildContext context) {
    return Scaffold(

      // appBar(nome da propriedade): AppBar(classe)
      appBar: AppBar(
        title: Text('Revisao'),
      ),

      body: Form(
        // Formulario exige uma chave para funcionar
        key: formularioChave,
        child: Padding(
          padding: EdgeInsetsGeometry.all(10),
          child: Column(
            children: [
              // Alterado o TextField para TextFormField para se adequar ao form
              // É um TextField especializado para lidar com o Form
              TextFormField(
                controller: _nomeControlador,
                decoration: InputDecoration(
                  labelText: 'Digite o nome do produto',
                  hintText: 'Ex: Coca Cola 2 litros',
                  border: OutlineInputBorder(),
                ),
                // validator é do TextFormField
                validator: validarNome,
              ),

              SizedBox(
                height: 20,
              ),

              TextFormField(
                controller: _precoControlador,
                decoration: InputDecoration(
                  labelText: 'Digite o preco produto',
                  hintText: 'Ex: 12.50',
                  border: OutlineInputBorder(),
                ),
                validator: validarPreco,
              ),

              SizedBox(height: 20,),

              TextFormField(
                controller: _quantidadeControlador,
                decoration: InputDecoration(
                  labelText: 'Digite a quantidade do produto',
                  hintText: 'Ex: 10',
                  border: OutlineInputBorder(),
                ),
                validator: validarQuantidade,
              ),

              SizedBox(height: 20,),

              Text(
                mensagem
              ),

              SizedBox(height: 20,),

              ElevatedButton(
                onPressed: (){Salvar();},
                child: Text('Salvar'),
              ),

            ]
          )
        )
      )

    );
  }
}