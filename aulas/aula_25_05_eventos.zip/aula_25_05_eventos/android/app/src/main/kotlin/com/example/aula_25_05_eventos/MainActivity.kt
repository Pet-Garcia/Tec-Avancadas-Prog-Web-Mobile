package com.example.aula_25_05_eventos

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
