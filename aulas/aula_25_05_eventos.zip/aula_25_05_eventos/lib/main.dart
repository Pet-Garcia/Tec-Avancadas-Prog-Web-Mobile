import 'package:aula_25_05_eventos/evento.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(EventoApp()); // Roda o aplicativo, a partir do widget raiz, que é o EntradaApp
  

}