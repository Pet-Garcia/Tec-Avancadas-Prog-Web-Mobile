import 'package:flutter/material.dart';
// SEMPRE 'MATERIAL'

class EventoApp extends StatelessWidget { // 1 Aplicativo
  @override
  Widget build(BuildContext context) { // Build 
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Tira a faixa de debug em cima da execução
      title: 'APP 2 - Entrada de dados/Eventos', // Título do aplicativo
      home: EventoPage(), // Página inicial do aplicativo, a primeira a ser exibida, a raiz da árvore de widgets, o ponto de partida do aplicativo
    );
  }
}

// Página stateless, sem estado, sem interação, sem mudança de dados, apenas exibição de informações
// Como a tela da história da Fatec, por exemplo

// Página stateful, com estado, com interação, com mudança de dados
// Como a tela de login, por exemplo
class EventoPage extends StatefulWidget { // cada app com suas n Páginas
  @override
  State<StatefulWidget> createState() { // createState
    return EventoState(); // Estado dessa página
  }
}


class EventoState extends State<EventoPage> { // e cada página com seu único Estado
  String nome = ''; // Declaração da variavel global
  int ano = 0;

  TextEditingController nomeControlador = /*não tem new*/ TextEditingController(); // Declaração de um controlador para inserir dentro da variavel nome o valor dado pelo usuario
  // Semelhante ao New do Java mas sem o new na frente do =
  TextEditingController idadeControlador = TextEditingController();

  // Declaração do método para o botão
  void enviar(){

    // Atualiza os componentes para que mostrem as alterações ocorridas
    setState(() {
      // Manda a variavel ser atualizada
      nome = nomeControlador.text; // Envia o valor do controlador para a variavel
    });
  }

  // Essa divisão é para afetar apenas o estritamente necessario
  void calcular(){
    int idade = int.tryParse(idadeControlador.text) ?? 0;
    setState(() {
      
      // O setState tem apenas o conteudo que vai ser atualizado
      ano = 2026 - idade;
    });
  }
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Page/State - Entrada de Dados')
        ),
      body: Padding( // Espaçamento interno do body, para não ficar colado nas bordas da tela
        padding: EdgeInsets.all(200), // 200 pixels de espaçamento em todas as direções
        child: Column( // Coluna, para organizar os widgets em vertical
          children: [ // Como se fosse um vetor, chamado de 'filhos' e coleção
            TextField( // Campo de texto, para entrada de dados
              decoration: InputDecoration(
                labelText: 'Qual é o seu nome?',
              ),

              // Para capturar o que o usuario digitou no campo, pode ser antes ou depois do decoration
              controller: nomeControlador,

            ),

            SizedBox( // Espaçamento entre widgets, para não ficar colado
              height: 20, // 20 pixels de altura
            ),

            TextField(
              controller: idadeControlador,
              decoration: InputDecoration(
                labelText: 'Qual é a sua idade?',
              ),
            ),

            SizedBox(
              height: 20,
            ),

            //Para puxar uma variavel para um texto
            Text('Boa tarde $nome!'),
            Text('O seu ano de nascimento é $ano'),

            SizedBox(
              height: 20,
            ),

            ElevatedButton(
              onPressed: enviar,// metódo void é chamado e executado
              child:
                Text('Enviar'),

            ),

            SizedBox(
              height: 20,
            ),

            // Pode ser no mesmo botão, mas foi preferido desse modo
            ElevatedButton(
              onPressed: calcular,// metódo void é chamado e executado
              child:
                Text('Calcular'),

            )
            
          ],
        )
      ), 


    );
  }
}