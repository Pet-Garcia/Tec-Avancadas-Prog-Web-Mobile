import 'package:flutter/material.dart';

class TelaLoginApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Login',
      home: TelaLoginPage(),

    );
  }
}

class TelaLoginPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return TelaLoginState();
  }
}

class TelaLoginState extends State<TelaLoginPage>{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //titulo da barra de navegação
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: EdgeInsetsGeometry.all(200)),
        child: Column()
    );
  }

}